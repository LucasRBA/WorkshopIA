# Bem-vindo ao Repositório WorkshopIA

### Aqui você encontrará os arquivos necessários e código para replicar as atividades feitas durante o workshop

